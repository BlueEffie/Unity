﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UnityPluginForWindowsPhone
{
    public class Class1
    {
        public static string GetDeviceName
        {
            get
            {
                return "Not Windows Phone";
            }
        }
    }
}
