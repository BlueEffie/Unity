﻿using UnityEditor;
using UnityEngine;
using System.Collections;
using System.IO;

public class BuildAssetBundlesWindow : EditorWindow
{
    BuildTarget m_BuildTarget = BuildTarget.WP8Player;
    
    // Add "Build Bundles" menu item
    [MenuItem("Window/Build Bundles")]
    static void ShowWindow()
    {
        EditorWindow.GetWindow<BuildAssetBundlesWindow>();
    }

    void OnGUI()
    {
        EditorGUILayout.Space();

        // Create button to build bundles
        if (GUILayout.Button("Build bundles"))
        {
            // If button is pressed, delete all currently built bundles and build new ones
            if (Directory.Exists(BundleDB.BundleOutputPath))
            {
                Directory.Delete(BundleDB.BundleOutputPath, true);
            }

            Directory.CreateDirectory(BundleDB.BundleOutputPath);

            foreach (var bundle in BundleDB.BundleInputOutputFilePairs)
            {
                BuildAssetBundles(BundleDB.BundleInputPath + bundle.Key, BundleDB.BundleOutputPath + bundle.Value);
            }
        }
    }

    void BuildAssetBundles(string inputPath, string outputPath)
    {
        // Load asset, set options, build bundle and refresh editor to import the newly created bundle.
        Object obj = AssetDatabase.LoadAssetAtPath(inputPath, typeof(GameObject));

        BuildAssetBundleOptions options = BuildAssetBundleOptions.UncompressedAssetBundle | BuildAssetBundleOptions.CollectDependencies;
        BuildPipeline.BuildAssetBundle(obj, new[] { obj }, outputPath, options, m_BuildTarget);
        AssetDatabase.Refresh();
    }
}
